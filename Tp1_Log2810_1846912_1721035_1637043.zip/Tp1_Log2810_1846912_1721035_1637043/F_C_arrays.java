package Tp1;

import java.util.ArrayList;

public class F_C_arrays{
    ArrayList<String> nodes_;
    double weight_;

    F_C_arrays(){
        this(null, 0);
    }

    F_C_arrays(ArrayList<String> nodes, double weight){
        this.nodes_ = nodes;
        this.weight_ = weight;
    }
}
